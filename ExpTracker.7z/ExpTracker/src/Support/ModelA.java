
package Support;

import java.util.ArrayList;

//Data manipulation.
//manage my array

public class ModelA {
    
    private ArrayList <Account> accounts;
    
     public ModelA(){
         accounts = new ArrayList<>();
     }
    
  //  ModelA(ArrayList <Tickets> myTickets){
  //      all_tickets = myTickets;
  //  }
    
    public void addAccount(Account account)
    {
        get_all_accounts().add(account);
      //  ticket.incTicketNum();
    }
    
//    public void printTickets()
//        {
//            System.out.println("Tickets: ");
//            get_all_accounts().forEach((account) -> {
//                account.print();
//        });
//        }
//    
    public ArrayList <Account> get_all_accounts() {
        return accounts;
    }

    public void setClassTickets(ArrayList <Account> accounts) {
        this.accounts = accounts;
    }
    
    public void add(Account a){
        this.accounts.add(a);
    }
    
    public int size(){
        return this.accounts.size();
    }
}