package Support;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import static javafx.scene.text.Font.font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javax.swing.JPasswordField;

/**
 *
 * @author Carlos
 */
public class ViewLogin extends BorderPane {

    GUI_GridPane myGrid = new GUI_GridPane();
    HBox center = new HBox();

    //Payment INFO
    public ViewLogin() {

        //GRIDPANE-INPUT/DISPLAY SYSTEM
        center.getChildren().add(myGrid);
        setCenter(center);
        center.setAlignment(Pos.CENTER);

    }

//Grid Pane for input info
    public class GUI_GridPane extends GridPane {

        private Label uNameLB = new Label("Username: ");
        private Label psswLB = new Label("Password: ");

        private TextField uNameTF = new TextField();
        private TextField psswTF = new TextField();
        //private JPasswordField psswPF = new JPasswordField(20);

        private Button loginBT = new Button("Login");
        private Button forgotPsswBT = new Button("Forgot password?");
        private Button createAccBT = new Button("Create account");

        public GUI_GridPane() {

            this.addRow(1, uNameLB, uNameTF);
            this.addRow(2, psswLB, psswTF);
            this.addRow(4, loginBT, createAccBT);
            this.addRow(5, forgotPsswBT);
            //this.addRow(6, creteAccBT);

        }        

        // to clear textfields
        void clear() {

            getuNameTF().clear();
        }

        /**
         * @return the uNameLB
         */
        public Label getuNameLB() {
            return uNameLB;
        }

        /**
         * @param uNameLB the uNameLB to set
         */
        public void setuNameLB(Label uNameLB) {
            this.uNameLB = uNameLB;
        }

        /**
         * @return the psswLB
         */
        public Label getPsswLB() {
            return psswLB;
        }

        /**
         * @param psswLB the psswLB to set
         */
        public void setPsswLB(Label psswLB) {
            this.psswLB = psswLB;
        }

        /**
         * @return the uNameTF
         */
        public TextField getuNameTF() {
            return uNameTF;
        }

        /**
         * @param uNameTF the uNameTF to set
         */
        public void setuNameTF(TextField uNameTF) {
            this.uNameTF = uNameTF;
        }

        /**
         * @return the psswTF
        */ 
        public TextField getPsswTF() {
            return psswTF;
        }

        /**
         * @param psswTF the psswTF to set
        */ 
        public void setPsswTF(TextField psswTF) {
            this.psswTF = psswTF;
        }
        /**
         * @return the loginBT
         */
        public Button getLoginBT() {
            return loginBT;
        }

        /**
         * @param loginBT the loginBT to set
         */
        public void setLoginBT(Button loginBT) {
            this.loginBT = loginBT;
        }

        /**
         * @return the forgotPsswBT
         */
        public Button getForgotPsswBT() {
            return forgotPsswBT;
        }

        /**
         * @param forgotPsswBT the forgotPsswBT to set
         */
        public void setForgotPsswBT(Button forgotPsswBT) {
            this.forgotPsswBT = forgotPsswBT;
        }

        /**
         * @return the createAccBT
         */
        public Button getCreateAccBT() {
            return createAccBT;
        }

        /**
         * @param createAccBT the createAccBT to set
         */
        public void setCreateAccBT(Button createAccBT) {
            this.createAccBT = createAccBT;
        }

        /**
         * @return the pssTF
         
        public JPasswordField getPssTF() {
            return pssTF;
        }

        /**
         * @param pssTF the pssTF to set
         
        public void setPssTF(JPasswordField pssTF) {
            this.pssTF = pssTF;
        }
        */
    }
}
