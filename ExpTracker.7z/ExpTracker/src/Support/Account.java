/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Support;
// instead of class violationtype, I used just an string array

public class Account {
    
    private String accountName;
    private String username;
    private String password;
    private String answerSq;
    private String[] securityQuestion;
    
    
    Account(){
     accountName = "";
     username = "";
     password = "";
     answerSq = "";
     securityQuestion = null;
    }
    
    Account( String aName, String uName, String pssw, String aSq){// String[] sQ){
        accountName = aName;
        username = uName;
        password = pssw;
        answerSq = aSq;
        //securityQuestion = sQ;
    }
    
    /**
     * @return the accountName
     */
    public String getAccountName() {
        return accountName;
    }

    /**
     * @param accountName the accountName to set
     */
    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return the securityQuestion
     */
    public String getAnswerSq() {
        return answerSq;
    }

    /**
     * @param Sq the answerSq to set
     */
    public void setAnswerSq(String Sq) {
        this.answerSq = Sq;
    }            

    /**
     * @return the securityQuestion
     */
    public String[] getSecurityQuestion() {
        return securityQuestion;
    }

    /**
     * @param securityQuestion the securityQuestion to set
     */
    public void setSecurityQuestion(String[] securityQuestion) {
        this.securityQuestion = securityQuestion;
    }
}
