/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Support;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javax.swing.JComboBox;
import javax.swing.JPasswordField;


/**
 *
 * @author Joshu
 */
public class ViewCreate extends BorderPane{
    
    ViewCreate.GUI_GridPane myGrid = new ViewCreate.GUI_GridPane();
    HBox center  = new HBox();
    
    public ViewCreate(){
       
        center.getChildren().add(myGrid);
       setCenter(center);
       center.setAlignment(Pos.CENTER);
    }
    
    public class GUI_GridPane extends GridPane {
    
        //Declaring
        
        private Label anameLB = new Label("Name: ");
        private Label uNameLB = new Label("Username: ");
        private Label psswLB = new Label("Password: ");
        private Label aQuestionLB = new Label("Answer: ");
    
    
        private TextField anameTF = new TextField();
        private TextField uNameTF = new TextField();
        private TextField psswTF = new TextField();
        private JPasswordField pssPF = new JPasswordField();
        private TextField aQuestionTF = new TextField();
        
        //private final JComboBox sQuestionCB = new JComboBox("Where did you born?", "Your mother's first name?", "Name of your first pet?");
        
        private Button submitBT = new Button("Submit");
    
        public GUI_GridPane() {
            
   
            //Implementing
        
            this.addRow(1, anameLB, anameTF);
            this.addRow(2, uNameLB, uNameTF);
            this.addRow(3, psswLB, psswTF);
            //this.addRow(4, sQuestionCB);
            this.addRow(5, aQuestionLB, aQuestionTF);
            this.addRow(5, submitBT);
        }

        /**
         * @return the anameLB
         */
        public Label getAnameLB() {
            return anameLB;
        }

        /**
         * @param anameLB the anameLB to set
         */
        public void setAnameLB(Label anameLB) {
            this.anameLB = anameLB;
        }

        /**
         * @return the uNameLB
         */
        public Label getuNameLB() {
            return uNameLB;
        }

        /**
         * @param uNameLB the uNameLB to set
         */
        public void setuNameLB(Label uNameLB) {
            this.uNameLB = uNameLB;
        }

        /**
         * @return the psswLB
         */
        public Label getPsswLB() {
            return psswLB;
        }

        /**
         * @param psswLB the psswLB to set
         */
        public void setPsswLB(Label psswLB) {
            this.psswLB = psswLB;
        }

        /**
         * @return the aQuestionLB
         */
        public Label getaQuestionLB() {
            return aQuestionLB;
        }

        /**
         * @param aQuestionLB the aQuestionLB to set
         */
        public void setaQuestionLB(Label aQuestionLB) {
            this.aQuestionLB = aQuestionLB;
        }

        /**
         * @return the anameTF
         */
        public TextField getAnameTF() {
            return anameTF;
        }

        /**
         * @param anameTF the anameTF to set
         */
        public void setAnameTF(TextField anameTF) {
            this.anameTF = anameTF;
        }

        /**
         * @return the uNameTF
         */
        public TextField getuNameTF() {
            return uNameTF;
        }

        /**
         * @param uNameTF the uNameTF to set
         */
        public void setuNameTF(TextField uNameTF) {
            this.uNameTF = uNameTF;
        }

        /**
         * @return the psswTF
         */
        public TextField getPsswTF() {
            return psswTF;
        }

        /**
         * @param psswTF the psswTF to set
         */
        public void setPsswTF(TextField psswTF) {
            this.psswTF = psswTF;
        }

        /**
         * @return the aQuestionTF
         */
        public TextField getaQuestionTF() {
            return aQuestionTF;
        }

        /**
         * @param aQuestionTF the aQuestionTF to set
         */
        public void setaQuestionTF(TextField aQuestionTF) {
            this.aQuestionTF = aQuestionTF;
        }

        /**
         * @return the submitBT
         */
        public Button getSubmitBT() {
            return submitBT;
        }

        /**
         * @param submitBT the submitBT to set
         */
        public void setSubmitBT(Button submitBT) {
            this.submitBT = submitBT;
        }

        /**
         * @return the pssPF
         */
        public JPasswordField getPssPF() {
            return pssPF;
        }

        /**
         * @param pssPF the pssPF to set
         */
        public void setPssPF(JPasswordField pssPF) {
            this.pssPF = pssPF;
        }
        
    }
}

  
