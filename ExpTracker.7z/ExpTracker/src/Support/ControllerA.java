/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Support;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.stage.Stage;


/**
 *
 * @author Carlos
 */
public class ControllerA {


    public int i = 0;
    ViewLogin view = new ViewLogin();
    static ViewCreate viewCreate = new ViewCreate();
    ModelA myData = new ModelA();
    
    private Scene scene = new Scene(view, 430, 460);
    private Stage stageC = new Stage();
    private Stage stage = new Stage();
    
    public ControllerA(ModelA model, ViewLogin view) {
        this.myData = model;
        this.view = view;
        attachHandlers();
        
    }

public void attachHandlers(){
      
    //submit button
   
    viewCreate.myGrid.getSubmitBT().setOnAction(new EventHandler<ActionEvent>()
            {
                
            public void handle(ActionEvent event){

                viewCreate.myGrid.getAnameTF().setEditable(true);
                viewCreate.myGrid.getuNameTF().setEditable(true);
                viewCreate.myGrid.getPsswTF().setEditable(true);
                viewCreate.myGrid.getaQuestionTF().setEditable(true);
                
                Account account = new Account(viewCreate.myGrid.getAnameTF().toString(), 
                        viewCreate.myGrid.getuNameTF().toString(), viewCreate.myGrid.getPsswTF().toString(),
                        viewCreate.myGrid.getaQuestionTF().toString());

                myData.get_all_accounts().add(account);
                view.myGrid.clear();
                
                try {
                    changeStagesToLogin();
                } catch (Throwable ex) {
                    Logger.getLogger(ControllerA.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    );
    
    view.myGrid.getLoginBT().setOnAction(new EventHandler<ActionEvent>() {

        public void handle(ActionEvent event) {

            //function to compare with accounts in DB and proceed to login if exists
            //change of stages to the account logged in view
            view.myGrid.clear();
        }
    }
    );

    view.myGrid.getCreateAccBT().setOnAction(new EventHandler<ActionEvent>() {

        public void handle(ActionEvent event) {

            Scene s = new Scene(viewCreate, 430, 460);
            changeStagesToCreate(s);
        }
    }
    );
     
}

public void changeStagesToCreate(Scene s){
    view.getScene().getWindow().hide();
    stageC.setScene(s);
    stageC.show();
    stageC.setResizable(true);
}

public void changeStagesToLogin() throws Throwable{
    this.finalize();
    stage.setScene(scene);
    stage.show();
    stage.setResizable(true);
}



//    /**
//     * @return the sceneC
//     */
//    public Scene getSceneC() {
//        return sceneC;
//    }
//
//    /**
//     * @param sceneC the sceneC to set
//     */
//    public void setSceneC(Scene sceneC) {
//        this.sceneC = sceneC;
//    }

    /**
     * @return the scene
     */
    public Scene getScene() {
        return scene;
    }

    /**
     * @param scene the scene to set
     */
    public void setScene(Scene scene) {
        this.scene = scene;
    }

    /**
     * @return the stageC
     */
//    public Stage getStageC() {
//        return stageC;
//    }

    /**
     * @param stageC the stageC to set
     */
//    public void setStageC(Stage stageC) {
//        this.stageC = stageC;
//    }

    /**
     * @return the stage
     */
    public Stage getStage() {
        return stage;
    }

    /**
     * @param stage the stage to set
     */
    public void setStage(Stage stage) {
        this.stage = stage;
    }

}
