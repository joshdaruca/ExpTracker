/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parking.citation.mvc.sp_2018;

import Support.ControllerA;
import Support.ModelA;
import Support.ViewLogin;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author Carlos
 */
public class main extends Application {
    
    @Override
    public void start(Stage primaryStage) {
       
    ViewLogin myView = new ViewLogin();
    ModelA myModel = new ModelA();
    ControllerA controller = new ControllerA(myModel,myView);
		
    Scene scene = new Scene(myView, 800, 700);
		
    primaryStage.setTitle("Hello MVC world!");
    primaryStage.setScene(scene);
    primaryStage.show();
    
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
